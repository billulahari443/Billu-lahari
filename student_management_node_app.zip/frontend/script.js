const form = document.getElementById("studentForm");
const table = document.getElementById("studentTable");
const message = document.getElementById("message");

async function loadStudents() {
  const response = await fetch("/api/students");
  const students = await response.json();

  table.innerHTML = students.map(s => `
    <tr>
      <td>${s.id}</td>
      <td>${s.name}</td>
      <td>${s.branch}</td>
      <td>${s.marks}</td>
      <td><button class="delete" onclick="deleteStudent(${s.id})">Delete</button></td>
    </tr>
  `).join("");
}

form.addEventListener("submit", async (event) => {
  event.preventDefault();

  const student = {
    name: document.getElementById("name").value,
    branch: document.getElementById("branch").value,
    marks: document.getElementById("marks").value
  };

  const response = await fetch("/api/students", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(student)
  });

  const result = await response.json();
  message.textContent = result.message || result.error;
  form.reset();
  loadStudents();
});

async function deleteStudent(id) {
  await fetch(`/api/students/${id}`, { method: "DELETE" });
  loadStudents();
}

loadStudents();